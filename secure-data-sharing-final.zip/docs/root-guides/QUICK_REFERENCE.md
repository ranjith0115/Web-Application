# Quick reference

Short commands and checks.

## Start services

Terminal 1 (Ganache):

```bash
ganache-cli --accounts 7 --deterministic --host 127.0.0.1 --port 7545
```

Terminal 2 (Deploy contract + backend):

```bash
python -m pip install -r backend/requirements.txt
python scripts/deploy_contract_compiled.py
python -m uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

Terminal 3 (Frontend):

```bash
cd frontend
npm install
npm start
```

## Demo accounts

- Admin: `admin` / `admin123`
- Employee: `alice` / `alice123`

## Quick checks

- Backend docs: http://127.0.0.1:8000/docs
- Storage health (GridFS): http://127.0.0.1:8000/storage/health
- Blockchain status (optional): `POST http://127.0.0.1:8000/api/access/blockchain/status`

## Storage (MongoDB GridFS)

Set these in `.env`:

- `STORAGE_BACKEND=mongo`
- `MONGODB_URI=mongodb://localhost:27017` (local) OR `mongodb+srv://...` (Atlas)
- `MONGODB_DB=secure_data_sharing` (optional)
- `MONGODB_FILES_BUCKET=encrypted_files` (optional)

GridFS collections:

- `encrypted_files.files`
- `encrypted_files.chunks`

## Troubleshooting

- Port already in use: check with `netstat -ano | findstr :8000` / `:3000`
- MongoDB error: open `/storage/health` to see the exact connection/auth error
- Contract issues: re-run `python scripts/deploy_contract_compiled.py`
