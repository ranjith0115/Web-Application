@echo off
setlocal

set "ROOT=%~dp0\..\.."
pushd "%ROOT%" || exit /b 1

REM Prefer the Python launcher if available
set "PY=python"
where py >nul 2>nul
if not errorlevel 1 set "PY=py -3"

%PY% --version >nul 2>nul
if errorlevel 1 (
  echo Python not found. Install Python 3.11+ then retry.
  popd
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating virtualenv (.venv)...
  %PY% -m venv .venv || (popd & exit /b 1)
)

echo Installing backend dependencies...
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
".venv\Scripts\python.exe" -m pip install -r backend\requirements.txt || (popd & exit /b 1)

echo.
echo (Optional) Deploying smart contract to Ganache...
".venv\Scripts\python.exe" scripts\deploy_contract_compiled.py
if errorlevel 1 (
  echo Contract deploy skipped/failed. Download flow may require Ganache + a deployed contract.
  echo You can retry later with: ".venv\Scripts\python.exe" scripts\deploy_contract_compiled.py
)

echo Starting FastAPI (http://127.0.0.1:8000)...
".venv\Scripts\python.exe" -m uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000

popd
exit /b 0