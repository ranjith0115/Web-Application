Param(
    [string]$BaseUrl = 'http://127.0.0.1:8000',
    [string]$Username = 'admin'
)

$ErrorActionPreference = 'Stop'

Write-Host "Using API: $BaseUrl" -ForegroundColor Cyan

$files = Invoke-RestMethod -Uri "$BaseUrl/files/all" -TimeoutSec 10
$smoke = ($files | Where-Object { $_.filename -eq 'smoke.txt' -and $_.owner -eq $Username } | Sort-Object id | Select-Object -Last 1)
if (-not $smoke) {
    throw "No smoke.txt found for user '$Username'. Upload one first."
}

$fileId = [string]$smoke.id
Write-Host "file_id: $fileId"

$req = @{
    file_id = $fileId
    user_id = $Username
    user_attributes = @{ role = 'admin'; department = 'IT'; clearance = 'high' }
} | ConvertTo-Json -Depth 5

$approval = Invoke-RestMethod -Method Post -Uri "$BaseUrl/api/access/request-key-approval" -ContentType 'application/json' -Body $req -TimeoutSec 30
$keyId = [string]$approval.key_id
Write-Host "key_id: $keyId"

$auth = Invoke-RestMethod -Uri "$BaseUrl/api/access/authorities" -TimeoutSec 10
$addrs = @()
foreach ($a in $auth.authorities) {
    if ($a -is [string]) { $addrs += $a }
    elseif ($a.address) { $addrs += $a.address }
}

if ($addrs.Count -lt 4) {
    throw "Need >=4 authority addresses, got $($addrs.Count)."
}

$simBody = @{
    key_id = $keyId
    authority_addresses = @($addrs[0], $addrs[1], $addrs[2], $addrs[3])
} | ConvertTo-Json -Depth 5

$sim = Invoke-RestMethod -Method Post -Uri "$BaseUrl/api/access/simulate-approvals" -ContentType 'application/json' -Body $simBody -TimeoutSec 60
$okCount = ($sim.results | Where-Object { $_.error -eq $null }).Count
Write-Host "simulate_ok: $okCount/$($sim.results.Count)"
if ($okCount -lt 4) {
    Write-Host ($sim | ConvertTo-Json -Depth 10)
    throw "Simulated approvals did not fully succeed."
}

$downloadUrl = "$BaseUrl/files/download/$($fileId)?username=$($Username)&key_id=$($keyId)"
Write-Host "GET $downloadUrl"

$resp = Invoke-WebRequest -Uri $downloadUrl -UseBasicParsing -TimeoutSec 60
Write-Host "download: $($resp.StatusCode) bytes=$($resp.RawContentLength)" -ForegroundColor Green

$previewLen = [Math]::Min(120, $resp.Content.Length)
Write-Host "preview: $($resp.Content.Substring(0, $previewLen))"
