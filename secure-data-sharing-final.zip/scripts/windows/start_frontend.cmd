
@echo off
setlocal

set "ROOT=%~dp0\..\.."
pushd "%ROOT%\frontend" || exit /b 1

where npm >nul 2>nul
if errorlevel 1 (
	echo npm not found. Install Node.js (includes npm) then retry.
	popd
	exit /b 1
)

if not exist "node_modules" (
	echo Installing frontend dependencies...
	call npm install || (popd & exit /b 1)
)

echo Starting React dev server (http://localhost:3000)...
call npm start

popd
exit /b 0
