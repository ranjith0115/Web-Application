
@echo off
setlocal

echo Starting Ganache on http://127.0.0.1:7545 ...

where ganache-cli >nul 2>nul
if not errorlevel 1 (
	ganache-cli --accounts 7 --deterministic --host 127.0.0.1 --port 7545
	exit /b %errorlevel%
)

where ganache >nul 2>nul
if not errorlevel 1 (
	ganache --wallet.totalAccounts 7 --wallet.deterministic --server.host 127.0.0.1 --server.port 7545
	exit /b %errorlevel%
)

where npx >nul 2>nul
if not errorlevel 1 (
	echo Ganache not found globally; running via npx...
	REM Some npm/npx versions prompt for install confirmation. Force yes.
	call npx --yes ganache --wallet.totalAccounts 7 --wallet.deterministic --server.host 127.0.0.1 --server.port 7545
	exit /b %errorlevel%
)

echo Ganache not found.
echo Install one of:
echo   npm install -g ganache-cli
echo   npm install -g ganache
echo.
pause
exit /b 1
