@echo off
setlocal

REM One-click launcher for Windows (opens 3 terminals)
REM - Ganache (7545)
REM - FastAPI backend (8000)
REM - React frontend (3000)

set "ROOT=%~dp0"
set "SCRIPTS=%ROOT%scripts\windows"

if not exist "%SCRIPTS%\start_ganache.cmd" (
	echo Missing: %SCRIPTS%\start_ganache.cmd
	echo This repo is incomplete. Re-pull or restore scripts/windows.
	exit /b 1
)

if not exist "%SCRIPTS%\start_backend.cmd" (
	echo Missing: %SCRIPTS%\start_backend.cmd
	echo This repo is incomplete. Re-pull or restore scripts/windows.
	exit /b 1
)

if not exist "%SCRIPTS%\start_frontend.cmd" (
	echo Missing: %SCRIPTS%\start_frontend.cmd
	echo This repo is incomplete. Re-pull or restore scripts/windows.
	exit /b 1
)

echo Starting Secure Data Sharing...
echo.

start "Ganache (7545)" cmd /k call "%SCRIPTS%\start_ganache.cmd"
start "Backend (8000)" cmd /k call "%SCRIPTS%\start_backend.cmd"
start "Frontend (3000)" cmd /k call "%SCRIPTS%\start_frontend.cmd"

echo.
echo Open UI: http://localhost:3000
echo API docs: http://127.0.0.1:8000/docs
echo Storage health: http://127.0.0.1:8000/storage/health
echo.
exit /b 0
