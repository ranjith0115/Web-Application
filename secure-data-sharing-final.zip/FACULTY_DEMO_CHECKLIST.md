# Demo checklist (5–10 minutes)

Open these:
- UI: http://localhost:3000
- Backend docs: http://127.0.0.1:8000/docs
- Storage health: http://127.0.0.1:8000/storage/health

Demo accounts:
- `admin` / `admin123`
- `alice` / `alice123`

Steps:
1) Login as `admin`
2) Upload a small file
   - Example policy: `role:admin AND department:IT`
3) Refresh `/storage/health`
   - `gridfs_files_count` should increase after upload
4) (Optional) Approvals workflow: go to `/access`
5) Download/decrypt: go to `/download`

Quick fixes:
- Backend: restart `uvicorn` on port 8000
- Frontend: restart `npm start` on port 3000
- MongoDB: check `/storage/health` error message
- Contract: re-run `python scripts/deploy_contract_compiled.py`
