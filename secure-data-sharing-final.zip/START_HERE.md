# Start here

Fast path to a working demo.

If you only read one guide: `docs/root-guides/QUICK_REFERENCE.md`.

## One-command start

- Windows: `START_EVERYTHING.bat`
- macOS/Linux: `START_EVERYTHING.sh`

## Manual start (recommended for presenting)

1) Start Ganache (local blockchain)

```bash
ganache-cli --accounts 7 --deterministic --host 127.0.0.1 --port 7545
```

2) Deploy the contract (auto)

```bash
python -m pip install -r backend/requirements.txt
python scripts/deploy_contract_compiled.py
```

If compilation/deploy fails on your network, deploy in Remix and just update `backend/blockchain/DEPLOYMENT_INFO.json`.

3) Configure storage (MongoDB GridFS)

- This project stores encrypted file blobs in MongoDB using GridFS.
- Choose one:
	- Local MongoDB (recommended for demos): `MONGODB_URI=mongodb://localhost:27017`
	- MongoDB Atlas: set `MONGODB_URI` to your `mongodb+srv://...` connection string

Quick config:
- Copy `.env.example` → `.env`
- Set:
	- `STORAGE_BACKEND=mongo`
	- `MONGODB_URI=...`
	- (Optional) `STORAGE_ALLOW_LOCAL_FALLBACK=true` for offline demos

4) Start the backend (run from repo root)

```bash
python -m uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

5) Start the frontend

```bash
cd frontend
npm install
npm start
```

## Demo flow

Pre-seeded demo accounts are created on backend startup:

- Admin: `admin` / `admin123`
- Employee: `alice` / `alice123`

Flow:
1) Log in as `admin`.
2) Upload a file and set an access policy.
3) Go to `/access` and request approvals.
4) Simulate approvals until threshold is met.
5) Download/decrypt from `/download`.

## Quick checks

- Backend docs: http://127.0.0.1:8000/docs
- API health: http://127.0.0.1:8000/
- Storage health (GridFS count): http://127.0.0.1:8000/storage/health

Windows end-to-end smoke test (approval → download):

```powershell
powershell -ExecutionPolicy Bypass -File scripts/windows/smoke_e2e_download.ps1
```

## Troubleshooting

| Problem | Fix |
|---|---|
| Ganache not reachable | Confirm `127.0.0.1:7545` and Ganache is running |
| Frontend can't reach API | Confirm backend is on `127.0.0.1:8000` |
| Contract misconfigured | Re-run `python scripts/deploy_contract_compiled.py` |
| MongoDB blocked/unavailable | Use local MongoDB or set `STORAGE_ALLOW_LOCAL_FALLBACK=true` |

For a short demo script, see `FACULTY_DEMO_CHECKLIST.md`.

